//
//  ViewController.swift
//  CoreMLDemo
//
//  Created by Afraz Siddiqui on 3/18/21.
//

import CoreML
import UIKit
import SwiftUI

class ViewController: UIViewController, UIImagePickerControllerDelegate, UINavigationControllerDelegate {

    private let imageView: UIImageView = {
        let imageView = UIImageView()
        imageView.image = UIImage(systemName: "photo")
        imageView.contentMode = .scaleAspectFit
        return imageView
    }()

    private let label: UILabel = {
        let label = UILabel()
        label.textAlignment = .center
        label.text = "Select Image"
        label.numberOfLines = 0
        return label
    }()
    
    private let Button: UIButton = {
        let Button = UIButton()
        Button.setTitle("recipes", for: .normal)
        Button.setTitleColor(.systemBlue, for: .normal)
        Button.addTarget(self, action: #selector(buttonAction), for: .touchUpInside) // 클릭 이벤트 지정
        return Button
    }()
   
    override func viewDidLoad() {
        super.viewDidLoad()
        view.addSubview(label)
        view.addSubview(imageView)
        view.addSubview(Button)

        let tap = UITapGestureRecognizer(
            target: self,
            action: #selector(didTapImage)
        )
        tap.numberOfTapsRequired = 1
        imageView.isUserInteractionEnabled = true
        imageView.addGestureRecognizer(tap)
        
        
    }

    @objc func didTapImage() {
        let picker = UIImagePickerController()
        picker.sourceType = .photoLibrary
        picker.delegate = self
        present(picker, animated: true)
    }

    override func viewDidLayoutSubviews() {
        super.viewDidLayoutSubviews()
        imageView.frame = CGRect(
            x: 20,
            y: view.safeAreaInsets.top,
            width: view.frame.size.width-40,
            height: view.frame.size.width-40)
        label.frame = CGRect(
            x: 20,
            y: view.safeAreaInsets.top+(view.frame.size.width-40)+10,
            width: view.frame.size.width-40,
            height: 100)
        Button.frame = CGRect(
            x: 20,
            y: view.safeAreaInsets.top+(view.frame.size.width-40)+60,
            width: view.frame.size.width-40,
            height: 100
            )
    }
    var text:String = ""
    private func analyzeImage(image: UIImage?) {
        guard let buffer = image?.resize(size: CGSize(width: 224, height: 224))?
                .getCVPixelBuffer() else {
            return
        }

        do {
            let config = MLModelConfiguration()
            let model = try TomatoOnion(configuration: config)
            let input = TomatoOnionInput(image: buffer)

            let output = try model.prediction(input: input)
            text = output.classLabel
            label.text = text
        }
        catch {
            print(error.localizedDescription)
        }
    }
    @objc func buttonAction(sender: UIButton!) {
    
        let pro = text
        print("")
        print("===============================")
        print("[A_Nice >> buttonAction() :: 버튼 클릭 수행 실시]")
        print("===============================")
        print(pro)
        if pro == "Tomato" {
            let vc = UIHostingController(rootView: tomato())
            present(vc, animated: true)
        }else if pro == "onion" {
            let onionVC = UIHostingController(rootView: onion())
            present(onionVC, animated: true)
        }
    }

    // Image Picker

    func imagePickerControllerDidCancel(_ picker: UIImagePickerController) {
        // cancelled
        picker.dismiss(animated: true, completion: nil)
    }

    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey : Any]) {
        picker.dismiss(animated: true, completion: nil)
        guard let image = info[UIImagePickerController.InfoKey.originalImage] as? UIImage else {
            return
        }
        imageView.image = image
        analyzeImage(image: image)
    }
    
}


