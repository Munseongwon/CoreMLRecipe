//
//  Tomato.swift
//  CoreMLDemo
//
//  Created by 준철 on 2022/11/23.
//

import SwiftUI
struct tomato {
    let imagename:String
    let title: String
    let url: String
}

struct TomatoList {
    static let topten(){
    
    }
}

struct Tomato_Previews: PreviewProvider {
    static var previews: some View {
        tomato()
    }
}
